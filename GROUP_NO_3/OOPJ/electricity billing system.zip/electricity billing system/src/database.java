
import java.sql.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author pranj
 */
public class database{
	private static final String DATABASE_URL = "jdbc:mysql://127.0.0.1/bill";
	private static final String DATABASE_USERNAME = "root";
	private static final String DATABASE_PASSWORD = "123456";
	private static final String INSERT_DETAILS = "INSERT INTO userinfo (meterNo, customerName, customerId, unitConsumed, monthyear) VALUES (?, ?, ?, ?, ?)";
	static int units;
	
	public Connection connectDatabase() {
        try {
            return DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
        } catch (SQLException e) {
            System.out.println("SQL Connection fail!");
        }
        return null;
   	}
	public void insertItem(int meterNo, String name, String id, int unit, String month) throws SQLException {
        try (Connection connection = connectDatabase();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_DETAILS)){
            preparedStatement.setInt(1, meterNo);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, id);
	    preparedStatement.setInt(4, unit);
	    preparedStatement.setString(5, month);
            database.units = unit;
            preparedStatement.executeUpdate();
            System.out.println("Successfully Inserted!");
        }
    	}
}
